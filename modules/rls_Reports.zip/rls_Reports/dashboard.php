<?php

ControllerFactory::getController('rls_Reports')->dashboardIndex();
