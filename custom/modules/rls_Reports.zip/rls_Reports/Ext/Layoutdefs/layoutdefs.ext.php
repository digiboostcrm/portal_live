<?php 
 //WARNING: The contents of this file are auto-generated


 // created: 2015-06-16 11:43:23
$layout_defs["rls_Reports"]["subpanel_setup"]['rls_scheduling_reports_rls_reports'] = array (
  'order' => 100,
  'module' => 'RLS_Scheduling_Reports',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_RLS_SCHEDULING_REPORTS_RLS_REPORTS_FROM_RLS_SCHEDULING_REPORTS_TITLE',
  'get_subpanel_data' => 'rls_scheduling_reports_rls_reports',
  'top_buttons' => 
  array (
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);

?>