<?php
if (!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

include_once 'modules/Users/views/view.edit.php';

class customUsersViewEdit extends UsersViewEdit
{

    function display()
    {
        require_once 'custom/include/custom_notification_functions.php';
        global $db, $app_list_strings;
        $saved_module_array = $saved_module_row = array();

        //Load user selected module preference
        $select_query = "SELECT module,id FROM notification_modules";
        $saved_module_result = $db->query($select_query);
        while ($saved_module_row = $db->fetchByAssoc($saved_module_result)) {
            $saved_module_array[$saved_module_row['id']] = $saved_module_row['module'];
        }

        $html = "<table width='95%' cellspacing='0' cellpadding='0' id='ModuleTable'  class='edit'>";
        $html .= '<tr>
            <td style="height:20px;margin:10px">
                <input type="button" name="selectAllModules" id="selectAllModules" value="Select All" onclick="checkAllmodules();">
                <input type="button" name="deselectAllModules" id="deselectAllModules" value="Deselect All" onclick="uncheckAllModules();">
            </td>
        </tr><tr><td>&nbsp;</td></tr>';

        $currentColumn = 0;
        $maxColumn = 4;
        $user = new User();
        if(!empty($_REQUEST['record'])){
            $user->retrieve($_REQUEST['record']);
        }
        $modules_name = getUNModulepreference($user->id);
        $modulelist = array_keys($modules_name);
        sort($saved_module_array);
        foreach ($saved_module_array as $module) {
            if (in_array($module, $modulelist)) {
                $check_module = "checked=checked";
                if ($modules_name[$module] == 1) {
                    $check_active = "checked=checked";
                } else {
                    $check_active = "";
                }
            } else {
                $check_module = "";
                $check_active = "";
            }

            $auto_hide_td = "<td style='height:20px;border:#ccc 1px solid;padding:3px 5px;width:25%'>
                        <div style='width:50%;float:left'>
                        <input type='checkbox' name='chkmodule[]' style='margin:0px 10px' value='{$module}' {$check_module}>
                        {$app_list_strings['moduleList'][$module]}
                        </div>
                        <div style='width:50%;float:left'>
                         Auto Hide
                        <input type='checkbox' name='is_active[{$module}]' style='margin:0px 10px 0px 10px' {$check_active}  >
                        </div>
                        </td>";
            if ($currentColumn < $maxColumn) {
                $html .= $auto_hide_td;
                $currentColumn++;
            } else {
                $html .= "</tr><tr>{$auto_hide_td}";
                $currentColumn = 1;
            }
        }
        if ($currentColumn < $maxColumn) {
            $diff = $maxColumn - $currentColumn;
        }
        for ($i = 0; $i < $diff; $i++) {
            $html .= "<td style='height:20px;border:#ccc 1px solid;padding:3px 5px;width:25%'> &nbsp;</td>";
        }

        $html .= '</tr></table>';
        if (count($saved_module_array) == 0) {
            $html = "<div class='edit'>
                   <span>No modules found for notification.</span>
                  </div>";
        }

        $this->ss->assign('NOTIFICATION_HTML', $html);

        echo '
            <script type="text/javascript">
            function checkAllmodules(){
                  var inputs =   document.getElementById("ModuleTable").getElementsByTagName("input");
                    for (var i = 0; i < inputs.length; i++) {
                        if(inputs[i].name.indexOf("chkmodule[]") == 0) {
                                inputs[i].checked =  true;
                        }
                    }
            }
            function uncheckAllModules(){
                  var inputs =   document.getElementById("ModuleTable").getElementsByTagName("input");
                    for (var i = 0; i < inputs.length; i++) {
                                inputs[i].checked =  false;
                    }
            }       
                      
         </script>';
        parent::display();
    }

}

?>