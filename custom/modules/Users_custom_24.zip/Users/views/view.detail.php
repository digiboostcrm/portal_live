<?php
if (!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

include_once 'modules/Users/views/view.detail.php';

class customUsersViewDetail extends UsersViewDetail
{

    function display()
    {
        global $db, $app_list_strings;
        require_once 'custom/include/custom_notification_functions.php';
        $select_query = "SELECT module,id FROM notification_modules";
        $saved_module_result = $db->query($select_query);
        $saved_module_array  = array();
        while ($saved_module_row = $db->fetchByAssoc($saved_module_result)) {
            $saved_module_array[$saved_module_row['id']] = $saved_module_row['module'];
        }

        $current_user_id = $_REQUEST['record'];
        $user = new User();
        $user->retrieve($current_user_id);
        $modules_name = getUNModulepreference($user->id);

        $html = "<table width='95%' cellspacing='0' cellpadding='0' id='ModuleTable' class='detail'>";

        $currentColumn = 0;
        $maxColumn = 4;
        sort($saved_module_array);
        foreach ($saved_module_array as $name) {
            if (array_key_exists($name, $modules_name)) {
                $module_checked = "checked=checked";
                if ($modules_name[$name] == 1) {
                    $checked = "checked=checked";
                } else {
                    $checked = "";
                }
            } else {
                $module_checked = "";
                $checked = "";
            }

            $auto_hide_td = "<td style='height:20px;border:#ccc 1px solid;padding:3px 5px;'>
                           <div style='width:50%;float:left'>
                          <input type='checkbox' name='chkmodule[]' style='margin:0px 10px' value='{$name}' {$module_checked} disabled='disabled'>
                          {$app_list_strings['moduleList'][$name]}
                           </div>
                           <div style='width:50%;float:left'>
                            Auto Hide
                           <input type='checkbox' name='is_active[]' style='margin:0px 10px 0px 10px' value='' {$checked} disabled='disabled'>
                           </div>
                          </td>";
            if ($currentColumn < $maxColumn) {
                $html .= $auto_hide_td;
                $currentColumn++;
            } else {
                $html .= "</tr><tr>{$auto_hide_td}";
                $currentColumn = 1;
            }
        }
        if ($currentColumn < $maxColumn) {
            $diff = $maxColumn - $currentColumn;
        }
        for ($i = 0; $i < $diff; $i++) {
            $html .= "<td style='height:20px;border:#ccc 1px solid;padding:3px 5px;width:25%'> &nbsp;</td>";
        }

        $html .= '</tr></table>';
        if (count($saved_module_array) == 0) {
            $html = "<div class='detail'>
                   <span>No modules found for notification.</span>
                  </div>";
        }
        $this->ss->assign('NOTIFICATION_HTML', $html);
        parent::display();
    }

}
